/* @author	Steff Bisinger
 * @file	Duck.java
 * @date	4/5/2015 - created
 * @brief	A duck that quacks and dances
*/



public class Duck{
	

	public Duck(){
		
	}

	public String quack(){
		return "Quack";
	}

	public String dance(){
		return "*shuffles about on duck feet*";
	}
}
