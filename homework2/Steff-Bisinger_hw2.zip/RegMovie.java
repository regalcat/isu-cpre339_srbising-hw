

public class RegMovie extends Movie {
	private String title;
	private int daysrented;
	
	public KidsMovie(String t){
		super(t);
	}
	
	
	public String getTitle(){
		return title;
	}
	
	public void setDays(int days){
		daysrented=days;
	}
	
	public int getDays(){
		return daysRented;
	}
	public int getPrice(){
		if (daysrented>2)
			return (daysrented-2)*1.5+2;
		return 2;
	}
}