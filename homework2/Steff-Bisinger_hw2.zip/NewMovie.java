

public class NewMovie extends Movie {
	private String title;
	private int daysrented;
	
	public KidsMovie(String t){
		super(t);
	}
	
	public String getTitle(){
		return title;
	}
	
	public void setDays(int days){
		daysrented=days;
	}
	
	public int getDays(){
		return daysRented;
	}
	
	public int getPrice(){
		return daysrented * 3;
	}
}