import java.util.ArrayList<E>;

public class Rental {
	//private int daysRented;
	private ArrayList<Movie> movies;
	private Customer c;
	
    public Rental(Customer customer) {
		//daysRented=_daysRented;
		movies=new ArrayList<Movie>();
		c=customer;
    }
    
    //public int getDaysRented() {
    //    return _daysRented;
    //}

	public void addMovie(Movie m){
		movies.add(m);
	}
	
	public void rmMovie (Movie m){
		movies.remove(m);
	}
	
	private static int getAmount(){
		int amount=0;
		for(int i=0; i<movies.size(); i++){
			amount+=movies.get(i).getPrice();
			c.addFRP(movies.get(i));
		}
		return amount;
	}
	
	private static String listMovies(){
		String list = "";
		for(int i=0; i<movies.size(); i++){
			list += movies.get(i).getTitle() + "\n";
		}
		return list;
	}
	
	public String printReceipt(){
		int total = getAmount();
		return "<html><header><title>Your Statement</title></header><body><p>You rented\n"+listMovies()+"</p><p>Your total is " + total.toString() + " and you earned " + c.getFRP() + "Frequent Renter Points!</p></body></html>");
	}
}