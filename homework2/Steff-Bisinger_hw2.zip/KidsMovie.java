

public class KidsMovie extends Movie {
	private String title;
	private int daysrented;
	
	public KidsMovie(String t){
		super(t);
	}
	
	public String getTitle(){
		return title;
	}
	
	public void setDays(int days){
		daysrented=days;
	}
	
	public int getDays(){
		return daysRented;
	}
	public int getPrice(){
		if (daysrented>3)
			return (daysrented-3)*1.5;
		return 1.5;
	}
}