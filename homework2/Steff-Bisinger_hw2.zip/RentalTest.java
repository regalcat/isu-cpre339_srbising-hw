

public class RentalTest{
	
	public main(int argc, String argv[]){
		//Instantiate variables
		RegMovie a = new RegMovie("Gone With the Wind");
		NewMovie b = new NewMovie("Guardians of the Galaxy");
		KidsMovie c = new KidsMovie("The Boxtrolls");
		RegMovie d = new RegMovie("Iron Man");
		Rental r = new Rental();
		Customer c = new Customer("Sally");
		
		a.setDays(3);
		b.setDays(3);
		c.setDays(8);
		d.setDays(4);
		r.add(a);
		r.add(b);
		r.add(c);
		r.add(d);
		r.rm(d);
		String html = r.printReceipt();
	}
}