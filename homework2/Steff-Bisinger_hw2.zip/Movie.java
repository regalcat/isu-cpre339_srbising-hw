
abstract class Movie {
    
    private String title;
	private int daysRented;
    
    public Movie(String _title) {
        title = _title;
		daysrented=0;
    }
    
    public String getTitle() {
        return title;
    }
	
	public void setDays(int days){
		daysrented=days;
	}
	
	public void getDays(){
		return daysRented;
	}
	abstract int getPrice();
}